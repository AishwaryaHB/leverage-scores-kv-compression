from transformers.cache_utils import Cache
from typing import Any, Dict, List, Optional, Tuple, Union
import torch
import numpy as np
from sklearn.cluster import KMeans


class SLSCache(Cache):
    """
    Simple Leverage Score (SLS) based KV cache compression.
    
    This method computes leverage scores for K and V independently and uses them to 
    identify the most important tokens to preserve, while merging less important ones.
    
    Parameters:
        max_length (`int`):
            The maximum cache length after compression.
        window_length (`int`):
            The length of the recent context window to always preserve.
        lambda_weight (`float`, defaults to 0.5):
            Weight parameter balancing the importance of key vs value leverage scores.
        n_samples (`int`, defaults to 10):
            Number of random samples for approximate leverage score computation.
    """

    is_sliding = False

    def __init__(self, max_length: int, window_length: int, lambda_weight: float = 0.5, n_samples: int = 10) -> None:
        super().__init__()
        self.key_cache: List[torch.Tensor] = []
        self.value_cache: List[torch.Tensor] = []
        self.max_length = max_length
        self.window_length = window_length
        self.lambda_weight = lambda_weight
        self.n_samples = n_samples

    def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
        """Returns the sequence length of the cached states."""
        if len(self.key_cache) <= layer_idx:
            return 0
        return self.key_cache[layer_idx].shape[-2]

    def get_max_cache_shape(self) -> Optional[int]:
        """Returns the maximum sequence length of the cache object."""
        return self.max_length

    def compute_leverage_scores(self, X: torch.Tensor) -> torch.Tensor:
        """
        Compute approximate leverage scores for matrix X.
        
        Args:
            X: Input tensor of shape [batch_size, num_heads, seq_len, head_dim]
            
        Returns:
            scores: Leverage scores of shape [batch_size, num_heads, seq_len]
        """
        # Reshape to combine batch and heads dimensions for processing
        batch_size, num_heads, seq_len, head_dim = X.shape
        X_reshaped = X.reshape(batch_size * num_heads, seq_len, head_dim)
        
        # Initialize scores tensor
        scores = torch.zeros(batch_size * num_heads, seq_len, device=X.device)
        
        # Process each batch+head combination
        for i in range(batch_size * num_heads):
            # Get the current batch+head matrix
            X_i = X_reshaped[i]
            
            # For small matrices or if n_samples is large enough, compute exact leverage scores
            if seq_len <= 1000 or head_dim <= 100 or seq_len <= self.n_samples:
                try:
                    # SVD approach for exact leverage scores
                    U, _, _ = torch.linalg.svd(X_i, full_matrices=False)
                    scores[i] = torch.sum(U**2, dim=1)
                except:
                    # Fallback to approximate method if SVD fails
                    S = torch.randn(head_dim, self.n_samples, device=X.device) / (self.n_samples**0.5)
                    Y = X_i @ S
                    scores[i] = torch.sum(Y**2, axis=1) / torch.sum(X_i**2)
            else:
                # Approximate leverage scores using random projection
                S = torch.randn(head_dim, self.n_samples, device=X.device) / (self.n_samples**0.5)
                Y = X_i @ S
                scores[i] = torch.sum(Y**2, axis=1) / torch.sum(X_i**2)
                
        # Reshape back to [batch_size, num_heads, seq_len]
        return scores.reshape(batch_size, num_heads, seq_len)
    
    def update(
        self,
        key_states: torch.Tensor,
        value_states: torch.Tensor,
        layer_idx: int,
        cache_kwargs: Optional[Dict[str, Any]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Updates the cache with the new key_states and value_states for the given layer_idx.
        Applies leverage score based compression when cache exceeds maximum length.
        """
        # [bsz, num_heads, seq_len, head_dim]
        if len(self.key_cache) <= layer_idx:
            # Empty cache
            self.key_cache.append(key_states)
            self.value_cache.append(value_states)

        else:
            # Growing cache
            self.key_cache[layer_idx] = torch.cat([self.key_cache[layer_idx], key_states], dim=-2)
            self.value_cache[layer_idx] = torch.cat([self.value_cache[layer_idx], value_states], dim=-2)

        key_cache = self.key_cache[layer_idx]
        value_cache = self.value_cache[layer_idx]

        # If cache is within max length, no compression needed
        if key_cache.shape[-2] <= self.max_length:
            return key_cache, value_cache

        # Split into window (recent tokens) and compressible part (older tokens)
        key_length = key_cache.shape[-2]
        comp_key, window_key = key_cache[..., :key_length-self.window_length, :], key_cache[..., key_length-self.window_length:, :]
        comp_value, window_value = value_cache[..., :key_length-self.window_length, :], value_cache[..., key_length-self.window_length:, :]
        
        # Compute leverage scores for compressible parts
        k_scores = self.compute_leverage_scores(comp_key)
        v_scores = self.compute_leverage_scores(comp_value)
        
        # Combine scores with weighting parameter lambda
        combined_scores = self.lambda_weight * k_scores + (1 - self.lambda_weight) * v_scores
        
        # Select top tokens based on combined scores
        num_to_keep = self.max_length - self.window_length
        
        # Process each batch and head separately
        batch_size, num_heads = comp_key.shape[:2]
        
        # Initialize tensors to hold the selected tokens
        selected_keys = torch.zeros(
            (batch_size, num_heads, num_to_keep, comp_key.shape[-1]), 
            device=comp_key.device, 
            dtype=comp_key.dtype
        )
        selected_values = torch.zeros(
            (batch_size, num_heads, num_to_keep, comp_value.shape[-1]), 
            device=comp_value.device, 
            dtype=comp_value.dtype
        )
        
        # Select top tokens for each batch and head
        for b in range(batch_size):
            for h in range(num_heads):
                # Get indices of top tokens by score
                top_indices = torch.topk(combined_scores[b, h], num_to_keep, dim=0).indices
                
                # Extract the selected keys and values
                selected_keys[b, h] = comp_key[b, h][top_indices]
                selected_values[b, h] = comp_value[b, h][top_indices]
        
        # Concatenate the selected tokens with the window
        self.key_cache[layer_idx] = torch.cat((selected_keys, window_key), dim=-2)
        self.value_cache[layer_idx] = torch.cat((selected_values, window_value), dim=-2)
        
        return self.key_cache[layer_idx], self.value_cache[layer_idx]


class LevScoreKVCache(Cache):
    """
    Leverage Score-Guided Merging (LevScore-KV) for KV cache compression.
    
    This method uses both leverage scores and token similarity to identify
    clusters of less important tokens to merge, while preserving high-leverage tokens.
    
    Parameters:
        max_length (`int`):
            The maximum cache length after compression.
        window_length (`int`):
            The length of the recent context window to always preserve.
        beta (`float`, defaults to 0.5):
            Weight for combining key leverage scores and attention-weighted value scores.
        gamma (`float`, defaults to 1.0):
            Temperature parameter controlling the weighting during merging.
        n_samples (`int`, defaults to 10):
            Number of random samples for approximate leverage score computation.
        query_history_size (`int`, defaults to 5):
            Number of recent queries to use for estimating attention patterns.
    """

    is_sliding = False

    def __init__(
        self, 
        max_length: int, 
        window_length: int, 
        beta: float = 0.5, 
        gamma: float = 1.0, 
        n_samples: int = 10,
        query_history_size: int = 5,
    ) -> None:
        super().__init__()
        self.key_cache: List[torch.Tensor] = []
        self.value_cache: List[torch.Tensor] = []
        self.query_history: List[List[torch.Tensor]] = []  # Store recent queries for each layer
        self.max_length = max_length
        self.window_length = window_length
        self.beta = beta
        self.gamma = gamma
        self.n_samples = n_samples
        self.query_history_size = query_history_size

    def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
        """Returns the sequence length of the cached states."""
        if len(self.key_cache) <= layer_idx:
            return 0
        return self.key_cache[layer_idx].shape[-2]

    def get_max_cache_shape(self) -> Optional[int]:
        """Returns the maximum sequence length of the cache object."""
        return self.max_length

    def compute_leverage_scores(self, X: torch.Tensor) -> torch.Tensor:
        """
        Compute approximate leverage scores for matrix X.
        
        Args:
            X: Input tensor of shape [batch_size, num_heads, seq_len, head_dim]
            
        Returns:
            scores: Leverage scores of shape [batch_size, num_heads, seq_len]
        """
        # Reshape to combine batch and heads dimensions for processing
        batch_size, num_heads, seq_len, head_dim = X.shape
        X_reshaped = X.reshape(batch_size * num_heads, seq_len, head_dim)
        
        # Initialize scores tensor
        scores = torch.zeros(batch_size * num_heads, seq_len, device=X.device)
        
        # Process each batch+head combination
        for i in range(batch_size * num_heads):
            # Get the current batch+head matrix
            X_i = X_reshaped[i]
            
            # For small matrices or if n_samples is large enough, compute exact leverage scores
            if seq_len <= 1000 or head_dim <= 100 or seq_len <= self.n_samples:
                try:
                    # SVD approach for exact leverage scores
                    U, _, _ = torch.linalg.svd(X_i, full_matrices=False)
                    scores[i] = torch.sum(U**2, dim=1)
                except:
                    # Fallback to approximate method if SVD fails
                    S = torch.randn(head_dim, self.n_samples, device=X.device) / (self.n_samples**0.5)
                    Y = X_i @ S
                    scores[i] = torch.sum(Y**2, axis=1) / torch.sum(X_i**2)
            else:
                # Approximate leverage scores using random projection
                S = torch.randn(head_dim, self.n_samples, device=X.device) / (self.n_samples**0.5)
                Y = X_i @ S
                scores[i] = torch.sum(Y**2, axis=1) / torch.sum(X_i**2)
                
        # Reshape back to [batch_size, num_heads, seq_len]
        return scores.reshape(batch_size, num_heads, seq_len)

    def compute_avls(
        self, 
        keys: torch.Tensor, 
        values: torch.Tensor, 
        recent_queries: List[torch.Tensor]
    ) -> torch.Tensor:
        """
        Compute Attention-Weighted Value Leverage Scores (AVLS).
        
        Args:
            keys: Key tensor of shape [batch_size, num_heads, seq_len, head_dim_k]
            values: Value tensor of shape [batch_size, num_heads, seq_len, head_dim_v]
            recent_queries: List of recent query tensors
            
        Returns:
            avls: AVLS scores of shape [batch_size, num_heads, seq_len]
        """
        batch_size, num_heads, seq_len, _ = keys.shape
        
        # Compute value leverage scores
        v_scores = self.compute_leverage_scores(values)
        
        # If no query history, return value leverage scores
        if not recent_queries:
            return v_scores
        
        # Initialize AVLS
        avls = torch.zeros_like(v_scores)
        
        # For each recent query, compute attention weights and update AVLS
        dk = keys.shape[-1]  # Key dimension
        num_queries = len(recent_queries)
        
        for q in recent_queries:
            # For each batch and head
            for b in range(batch_size):
                for h in range(num_heads):
                    # Compute attention weights
                    logits = torch.matmul(q[b, h], keys[b, h].transpose(-1, -2)) / (dk ** 0.5)
                    attention = torch.softmax(logits, dim=-1)
                    
                    attention = attention.squeeze(0) ## Remove extra dimensions to get [seq_len]
                    
                    # Update AVLS with attention-weighted value leverage scores
                    avls[b, h] += attention * v_scores[b, h]
        
        # Average over queries
        if num_queries > 0:
            avls = avls / num_queries
            
        return avls

    def cluster_and_merge(
        self,
        keys: torch.Tensor,
        values: torch.Tensor,
        combined_scores: torch.Tensor,
        num_pivots: int,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Cluster and merge tokens based on combined leverage scores.
        
        Args:
            keys: Key tensor [batch_size, num_heads, seq_len, head_dim_k]
            values: Value tensor [batch_size, num_heads, seq_len, head_dim_v]
            combined_scores: Combined score tensor [batch_size, num_heads, seq_len]
            num_pivots: Number of pivot tokens to preserve
            
        Returns:
            merged_keys, merged_values: Compressed key and value tensors
        """
        batch_size, num_heads, seq_len, key_dim = keys.shape
        _, _, _, value_dim = values.shape
        
        # Initialize tensors for results
        merged_keys = torch.zeros(
            (batch_size, num_heads, num_pivots, key_dim), 
            device=keys.device, 
            dtype=keys.dtype
        )
        merged_values = torch.zeros(
            (batch_size, num_heads, num_pivots, value_dim), 
            device=values.device, 
            dtype=values.dtype
        )
        
        # Process each batch and head
        for b in range(batch_size):
            for h in range(num_heads):
                # Get current tokens and scores
                batch_head_keys = keys[b, h]
                batch_head_values = values[b, h]
                batch_head_scores = combined_scores[b, h]
                
                # Get indices of top tokens by score (pivot tokens)
                _, pivot_indices = torch.topk(batch_head_scores, num_pivots, dim=0)
                
                # If number of pivots equals sequence length, just copy all tokens
                if num_pivots >= seq_len:
                    merged_keys[b, h] = batch_head_keys
                    merged_values[b, h] = batch_head_values
                    continue
                
                # Extract pivot tokens
                pivot_keys = batch_head_keys[pivot_indices]
                pivot_values = batch_head_values[pivot_indices]
                
                # Store pivot tokens in result
                merged_keys[b, h] = pivot_keys
                merged_values[b, h] = pivot_values
                
                # If all tokens are pivots, continue to next batch/head
                if num_pivots == seq_len:
                    continue
                
                # Create mask for non-pivot tokens
                is_pivot = torch.zeros(seq_len, dtype=torch.bool, device=keys.device)
                is_pivot[pivot_indices] = True
                non_pivot_indices = torch.nonzero(~is_pivot).squeeze(-1)
                
                # If there are no non-pivot tokens, continue
                if len(non_pivot_indices) == 0:
                    continue
                
                # Extract non-pivot tokens and their scores
                non_pivot_keys = batch_head_keys[non_pivot_indices]
                non_pivot_values = batch_head_values[non_pivot_indices]
                non_pivot_scores_k = batch_head_scores[non_pivot_indices]
                
                # For each pivot token, find nearest non-pivot tokens and merge them
                for i, pivot_idx in enumerate(pivot_indices):
                    # Compute similarity to this pivot
                    pivot_key = batch_head_keys[pivot_idx:pivot_idx+1]  # Keep dim
                    similarity = torch.nn.functional.cosine_similarity(
                        pivot_key, non_pivot_keys, dim=-1
                    )
                    
                    # Compute weights for merging based on leverage scores and similarity
                    # Higher similarity and lower leverage score -> higher weight
                    weights = torch.exp(-self.gamma * non_pivot_scores_k) * \
                             torch.exp(similarity)
                    
                    # Normalize weights
                    if torch.sum(weights) > 0:
                        weights = weights / torch.sum(weights)
                        
                        # Weighted average of non-pivot keys and values
                        weighted_keys = torch.sum(weights.unsqueeze(-1) * non_pivot_keys, dim=0)
                        weighted_values = torch.sum(weights.unsqueeze(-1) * non_pivot_values, dim=0)
                        
                        # Blend with the pivot token
                        merged_keys[b, h, i] = (pivot_key[0] + weighted_keys) / 2
                        merged_values[b, h, i] = (pivot_values[i] + weighted_values) / 2
        
        return merged_keys, merged_values

    def update(
        self,
        key_states: torch.Tensor,
        value_states: torch.Tensor,
        layer_idx: int,
        cache_kwargs: Optional[Dict[str, Any]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Updates the cache with new key_states and value_states for the given layer_idx.
        Applies leverage score-guided merging when cache exceeds maximum length.
        """
        # Extract query from cache_kwargs if available
        current_query = None
        if cache_kwargs is not None and 'query' in cache_kwargs:
            current_query = cache_kwargs['query']
        
        # Initialize query history for this layer if not exists
        if len(self.query_history) <= layer_idx:
            self.query_history.append([])
        
        # Update query history for this layer
        if current_query is not None:
            self.query_history[layer_idx].append(current_query)
            # Keep only the most recent queries
            if len(self.query_history[layer_idx]) > self.query_history_size:
                self.query_history[layer_idx] = self.query_history[layer_idx][-self.query_history_size:]
        
        # [bsz, num_heads, seq_len, head_dim]
        if len(self.key_cache) <= layer_idx:
            # Empty cache
            self.key_cache.append(key_states)
            self.value_cache.append(value_states)
        else:
            # Growing cache
            self.key_cache[layer_idx] = torch.cat([self.key_cache[layer_idx], key_states], dim=-2)
            self.value_cache[layer_idx] = torch.cat([self.value_cache[layer_idx], value_states], dim=-2)

        key_cache = self.key_cache[layer_idx]
        value_cache = self.value_cache[layer_idx]

        # If cache is within max length, no compression needed
        if key_cache.shape[-2] <= self.max_length:
            return key_cache, value_cache

        # Split into window (recent tokens) and compressible part (older tokens)
        key_length = key_cache.shape[-2]
        comp_key, window_key = key_cache[..., :key_length-self.window_length, :], key_cache[..., key_length-self.window_length:, :]
        comp_value, window_value = value_cache[..., :key_length-self.window_length, :], value_cache[..., key_length-self.window_length:, :]
        
        # Compute leverage scores for keys and values
        k_scores = self.compute_leverage_scores(comp_key)
        
        # Compute attention-weighted value leverage scores
        av_scores = self.compute_avls(comp_key, comp_value, self.query_history[layer_idx])
        
        # Combine scores
        combined_scores = self.beta * k_scores + (1 - self.beta) * av_scores
        
        # Number of tokens to keep after compression (excluding window)
        num_pivots = self.max_length - self.window_length
        
        # Cluster and merge tokens
        merged_keys, merged_values = self.cluster_and_merge(
            comp_key, comp_value, combined_scores, num_pivots
        )
        
        # Concatenate merged tokens with window
        self.key_cache[layer_idx] = torch.cat((merged_keys, window_key), dim=-2)
        self.value_cache[layer_idx] = torch.cat((merged_values, window_value), dim=-2)
        
        return self.key_cache[layer_idx], self.value_cache[layer_idx]
